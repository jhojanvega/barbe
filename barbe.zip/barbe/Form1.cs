﻿using MySql.Data.MySqlClient;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace barbe
{
    public partial class Form1 : Form

    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
          

           
           

            
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

      

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void name_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 a = new Form3();
            this.Hide();
            a.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
            string usur = usuario.Text;
            string psw = pass.Text;
            if (string.IsNullOrEmpty(usur) || string.IsNullOrEmpty(psw))

            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }

            string cadena = "SELECT p.idpersonas FROM persona_rol ps INNER JOIN rol r ON r.idrol = ps.rol_idrol INNER JOIN personas p ON p.idpersonas = ps.personas_idpersonas WHERE p.nombre = '" + usur +"' AND p.contraseña = '" + psw + "' AND ps.personas_idpersonas = 1 AND ps.rol_idrol = 1";
            MySqlCommand comando = new MySqlCommand(cadena,conexion);
            MySqlDataReader reader = comando.ExecuteReader();
            if (reader.Read())
            {
                Form3 a = new Form3();
                this.Hide();
                a.Show();
            }
            else
            {
                MessageBox.Show("No cuenta con los permisos.");
            }
            
            


        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
        }

        private void pbocultar_Click(object sender, EventArgs e)
        {
            if (pass.UseSystemPasswordChar)
            {
                pass.UseSystemPasswordChar = false;
            }
            else
            {
                pass.UseSystemPasswordChar = true;
            }
            pbver.Visible = false;
            pbocultar.Visible = true;
        }

        private void pbver_Click(object sender, EventArgs e)
        {
            if (pass.UseSystemPasswordChar)
            {
                pass.UseSystemPasswordChar = false;
            }
            else
            {
                pass.UseSystemPasswordChar = true;
            }
            pbver.Visible = true;
            pbocultar.Visible = false;
        }
    }
}

