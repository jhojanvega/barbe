﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace barbe
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }


        private void button4_Click(object sender, EventArgs e)
        {
         
            
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
  
            
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
                  
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Form3 a = new Form3();
            this.Hide();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 a = new Form4();
            this.Hide();
            a.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedCells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedCells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedCells[3].Value.ToString();
            textBox4.Text = dataGridView1.SelectedCells[2].Value.ToString();
           
            button5.Enabled = false;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); 
            conexion.Open();
            string nom = textBox1.Text;
            string ape = textBox2.Text;
            string cor = textBox4.Text;
            string tel = textBox3.Text;
          

            if (string.IsNullOrEmpty(nom) || string.IsNullOrEmpty(ape) || string.IsNullOrEmpty(cor) || string.IsNullOrEmpty(tel))

            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }
            string cadena = "INSERT INTO personas(nombre,apellido,correo,telefono) values ('" + nom + "','" + ape + "','" + cor + "','" + tel + "')";
            
            MySqlCommand comando = new MySqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();
            MessageBox.Show("Los datos se guardaron correctamente");
           textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            
            conexion.Close();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
           MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
            string cadena = "SELECT personas.nombre,personas.apellido,personas.correo,personas.telefono FROM personas where idpersonas <> 1";



            MySqlDataAdapter adaptador = new MySqlDataAdapter(cadena, conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); 
            conexion.Open();
            string cod = textBox5.Text;
            if (string.IsNullOrEmpty(cod))

            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }

            string cadena = "delete from personas where idPersonas="+ cod;
            MySqlCommand comando = new MySqlCommand(cadena, conexion);
            int cant;
            cant = comando.ExecuteNonQuery();
            if (cant == 1)
            {
                
                label10.Text = "";
                MessageBox.Show("Se borró el artículo");
                textBox5.Text = string.Empty;
            }
            else
                MessageBox.Show("No existe un artículo con el código ingresado");
            conexion.Close();
            button8.Enabled = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
            string cod = textBox5.Text;
            if (string.IsNullOrEmpty(cod))

            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }
            if (textBox5.Text == "1")
            {
                MessageBox.Show("no existe este nombre");
                return;
            }
            string cadena = "select nombre from personas where idPersonas =" + cod;
            MySqlCommand comando = new MySqlCommand(cadena, conexion);
            MySqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                label10.Text = registro["nombre"].ToString();
            }
            else
                MessageBox.Show("esta persona no existe");
            conexion.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text))

            {
               
                return;
            }


            else if (!int.TryParse(textBox5.Text, out _))
            {
                // Si el valor no es un número, muestra un mensaje de error y borra el contenido del TextBox.
                MessageBox.Show("Este campo solo acepta números.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox5.Text = string.Empty; // Borra el contenido del TextBox.
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
            string co = textBox5.Text;
            string n = textBox6.Text;
            string p = textBox7.Text;
            if (string.IsNullOrEmpty(co) || (string.IsNullOrEmpty(n) || (string.IsNullOrEmpty(p))))

            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }
            string cadena = "UPDATE personas SET nombre='" + n + "', apellido='" + p + "' WHERE idPersonas=" + co;
            MySqlCommand comando = new MySqlCommand(cadena, conexion);
            int cant;
            cant = comando.ExecuteNonQuery();
            if (cant == 1)
            {
                MessageBox.Show("Se modificaron los datos del artículo");
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
            }
            else
                MessageBox.Show("No existe un artículo con el código ingresado");
            conexion.Close();
           
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            Form3 a = new Form3();
            this.Hide();
            a.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form4 a = new Form4();
            this.Hide();
            a.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
          
            Form5 form5 = new Form5();
            form5.Show();
            this.Hide();
        }

        private void panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))

            {

                return;
            }


            else if (!BigInteger.TryParse(textBox3.Text, out _))
            {
                // Si el valor no es un número, muestra un mensaje de error y borra el contenido del TextBox.
                MessageBox.Show("Este campo solo acepta números.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox3.Text = string.Empty; // Borra el contenido del TextBox.
            }
        }
    }
    
}
