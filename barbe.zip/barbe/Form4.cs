﻿using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace barbe
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); 
            conexion.Open();
            string cod = textBox2.Text;
            if (string.IsNullOrEmpty(cod))

            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }
            string cadena = "delete from servicio where idservicio=" + cod;
            MySqlCommand comando = new MySqlCommand(cadena, conexion);
            int cant;
            cant = comando.ExecuteNonQuery();
            if (cant == 1)
            {

                label4.Text = "";
                MessageBox.Show("Se borró el artículo");
            }
            else
                MessageBox.Show("No existe un artículo con el código ingresado");
            conexion.Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedCells[0].Value.ToString();
           
            button5.Enabled = false;
            button7.Enabled = true;


        }

        private void button5_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); conexion.Open();
            string nom = textBox1.Text;
           
            if (string.IsNullOrEmpty(nom))
            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }
            string cadena = "INSERT INTO servicio(nombre_servicio) values ('" + nom + "')";
            MySqlCommand comando = new MySqlCommand(cadena, conexion);
            comando.ExecuteNonQuery();
            MessageBox.Show("Los datos se guardaron correctamente");
            textBox1.Text = "";
            
            conexion.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
            string cod = textBox2.Text;
            if (string.IsNullOrEmpty(cod))

            {
                MessageBox.Show("No dejar campos vacíos.");
                conexion.Close();
                return;
            }
            string cadena = "select nombre_servicio from servicio where idservicio=" + cod;
            MySqlCommand comando = new MySqlCommand(cadena, conexion);
            MySqlDataReader registro = comando.ExecuteReader();
            if (registro.Read())
            {
                label4.Text = registro["nombre_servicio"].ToString();
            }
            else
                MessageBox.Show("No existe un artículo con el código ingresado");
            conexion.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
            string cadena = "SELECT servicio.nombre_servicio FROM servicio";



            MySqlDataAdapter adaptador = new MySqlDataAdapter(cadena, conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button5.Enabled = true;
            textBox1.Text = "";
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 a = new Form3();
            this.Hide();
            a.Show();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
