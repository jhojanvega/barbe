﻿using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace barbe
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            servicios();
            metodopago();
            nomp();
            nomb();
            Presios();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
            
           





        }



        private void button6_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;");
            conexion.Open();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            comboBox4.Text = dataGridView1.SelectedCells[0].Value.ToString();
            dateTimePicker2.Text = dataGridView1.SelectedCells[2].Value.ToString();
            dateTimePicker1.Text = dataGridView1.SelectedCells[3].Value.ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); conexion.Open();
            string cadena = "SELECT personas.nombre,barbero.nombreb,citas.fecha,citas.hora,citas.horafin,servicio.nombre_servicio,presios.precio,metodopago.metodo,metodocita.valor FROM citas INNER JOIN persona_rol ON persona_rol.idpersona_rol = citas.persona_rol_idpersona_rol INNER JOIN personas ON personas.idpersonas = persona_rol.personas_idpersonas INNER JOIN barbero ON citas.idbarbero=barbero.idbarbero INNER JOIN presios ON citas.presios_idpresios = presios.idpresios INNER JOIN servicio ON presios.servicio_idservicio = servicio.idservicio INNER JOIN metodocita ON citas.idcitas = metodocita.idcitas INNER JOIN metodopago ON metodocita.idmet = metodopago.idmetodo;";

            MySqlDataAdapter adaptador = new MySqlDataAdapter(cadena, conexion);
            DataTable dt = new DataTable();
            adaptador.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            comboBox4.Text = dataGridView1.SelectedCells[0].Value.ToString();


            dateTimePicker2.Text = dataGridView1.SelectedCells[2].Value.ToString();
            dateTimePicker1.Text = dataGridView1.SelectedCells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedCells[4].Value.ToString();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Presios();
        }
        private void servicios()
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); conexion.Open();
            comboBox1.DataSource = null;
            comboBox1.Items.Clear();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            string cadena = "select idservicio, nombre_servicio from servicio";
            try
            {
                MySqlCommand comando = new MySqlCommand(cadena, conexion);
                MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                adaptador.Fill(dt);
                comboBox1.ValueMember = "idservicio";
                comboBox1.DisplayMember = "nombre_servicio";
                comboBox1.DataSource = dt;
              
            }
            catch
            {
                MessageBox.Show("error");

            }
            finally { conexion.Close(); }

        }

        private void Presios()
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); conexion.Open();
            string serv = comboBox1.SelectedValue.ToString();
            string query = "SELECT precio.precio FROM precio INNER JOIN servicio ON precio.servicio_idservicio = servicio.idservicio WHERE servicio.idservicio = " + serv;
            MySqlCommand com = new MySqlCommand(query, conexion);
            MySqlDataReader reader = com.ExecuteReader();

            if (reader.Read())
            {
                textBox5.Text = reader.GetString(0);
            }
            else
            {
                textBox5.Text = "Precio no encontrado";
            }
            reader.Close();
            conexion.Close();

        }

        
        private void metodopago ()
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); conexion.Open();
            comboBox2.DataSource = null;
            comboBox2.Items.Clear();
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            string cadena = "select idmetodo, metodo from metodopago";
            try
            {
                MySqlCommand comando = new MySqlCommand(cadena, conexion);
                MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                adaptador.Fill(dt);
                comboBox2.ValueMember = "idmetodo";
                comboBox2.DisplayMember = "metodo";
                comboBox2.DataSource = dt;
            }
            catch
            {
                MessageBox.Show("error");

            }
            finally { conexion.Close(); }
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void nomp()
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); conexion.Open();
            comboBox4.DataSource = null;
            comboBox4.Items.Clear();
            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            string cadena = "select idpersonas, nombre from personas where idpersonas<>1";
            try
            {
                MySqlCommand comando = new MySqlCommand(cadena, conexion);
                MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                adaptador.Fill(dt);
                comboBox4.ValueMember = "idpersonas";
                comboBox4.DisplayMember = "nombre";
                comboBox4.DataSource = dt;
            }
            catch
            {
                MessageBox.Show("error");

            }
            finally { conexion.Close(); }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void nomb()
        {
            MySqlConnection conexion = new MySqlConnection("server=localhost; database=barberiaa; Uid=root; Pwd=;"); conexion.Open();
            comboBox3.DataSource = null;
            comboBox3.Items.Clear();
            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            string cadena = "select idbarbero, nombreb from barbero";
            try
            {
                MySqlCommand comando = new MySqlCommand(cadena, conexion);
                MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                DataTable dt = new DataTable();
                adaptador.Fill(dt);
                comboBox3.ValueMember = "idbarbero";
                comboBox3.DisplayMember = "nombreb";
                comboBox3.DataSource = dt;
            }
            catch
            {
                MessageBox.Show("error");

            }
            finally { conexion.Close(); }
        }
    }
}
