﻿using System;
using MySql.Data.MySqlClient;

namespace barbe
{
    internal class MySqlConecction
    {
        private string sql;

        public MySqlConecction(string sql)
        {
            this.sql = sql;
        }

        internal void close()
        {
            throw new NotImplementedException();
        }

        internal void Open() => throw new NotImplementedException();   
        internal void Close() => throw new NotImplementedException();
    }
}